/*******************************************************************************
 Explorer 16 Demo Main File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    Explorer 16 Demo Main File.

  Description: 
    This is the main file for the Explorer 16 Demo. It contains the main demo
    flow and calls processor specific files for processor specific
    implementations.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************


#define FOSC (7370000ULL)
#define FCY (FOSC/2)

#include <libpic30.h>
#include "mcc_generated_files/mcc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdbool.h>

#define ONE_VOLT 310
#define ONE_TENTH_VOLT 31
#define ONE_HUNDREDTH_VOLT 3

// state declarations
#define IDLE 1
#define CHECK_BEER 2
#define LOADING 3
#define LAUNCH_PREP 4
#define LAUNCH 5
// PWM port declarations
//#define PWM_PORT1  PORTDbits.RD1
//#define PWM_TRIS1  TRISDbits.TRISD1
// limit switch "button style" port declarations
#define beer_PORT PORTDbits.RD11
#define beer_TRIS TRISDbits.TRISD11
#define test_PORT PORTDbits.RD5
#define test_TRIS TRISDbits.TRISD5
// UART ports
//#define RX_port PORTFbits.RF2
//#define RX_TRIS TRISFbits.TRISF2
//#define CTS_port PORTDbits.RD9
//#define CTS_TRIS TRISDbits.TRISD9

// *****************************************************************************
// *****************************************************************************
// Section: File Scope Variables and Functions
// *****************************************************************************
// *****************************************************************************

void pwm_testing ( void );
void limit_testing (void);
void UART_testing();
void transmit(uint8_t * buffer, int buf_length);
void servoRotate180();
void servoRotate90();
void servoRotate0();

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
int main ( void )
{
    /* Call the System Initialize routine*/
    SYSTEM_Initialize();
    OSCILLATOR_Initialize();
    /* Enable LEDs*/
    ///LED_Enable ( LED_D10 ) ;
    /* Enable Switch S3*/
    ///BUTTON_Enable ( BUTTON_S3 ) ;
    ///PRINT_SetConfiguration ( PRINT_CONFIGURATION_LCD ) ;

    /* Display welcome message */
    ///LCD_PutString ( (char*) &appData.messageLine1[0] , sizeof (appData.messageLine1 ) - 1  ) ;
    ///LCD_PutString ( (char*) &appData.messageLine2[0] , sizeof (appData.messageLine2 ) - 1  ) ;

    /* wait here until switch S3 is pressed */
    ///while (!BUTTON_IsPressed ( BUTTON_S3 )) ;
    
    // initialize the limit switch and PWM tristate buffers
    beer_TRIS = 1; //define as input to micro
    // UART transmission variables
    int numBytesWritten;
    int i; // for loopies
    int angle;
    int distance;
    int distance_decimal;
    //char * angle_str;
    //char * distance_str;
    int buf_length = 6; // number of characters to be read
    unsigned int numBytesRead; // local variables to grab values in debugger
    uint8_t buffer[buf_length]; // buffer to read to
    char char_buffer[buf_length]; // buffer to character conversion
    //char part_1[2];
    //char part_3[1];
    // loop initializations
    int state = IDLE;
    int n_state = IDLE;
    ///char no_kinect_message[] = "WAITING ON KINECT";
    ///char no_beer_string[] = "NO BEER, DAB AGAIN W/ BEER";
    ///char loading_string[] = "LOADING...";
    ///char prep_string[] = "PREPPING FOR LAUNCH...";
    ///char ERROR[] = "ERROR";
    limit_testing();
    while (1)
    {
        state = n_state;
        switch (state)
        {
            case IDLE :
                if(UART1_ReceiveBufferIsFull())
                {
                    // buffer is full, read data buffer
                    numBytesRead = UART1_ReadBuffer(buffer, buf_length);
                    // echo it back to laptop
                    numBytesWritten = UART1_WriteBuffer(buffer , buf_length);
                    // translate buffer bytes into chars
                    for (i=0; i < buf_length; i++) {char_buffer[i] = (char) (buffer[i]);}
                    ///LCD_ClearScreen();
                    ///LCD_PutString((char*)&char_buffer, buf_length); // print it to screen
                    __delay_ms(2500);
                    // set next state
                    n_state = CHECK_BEER;
                    // data conversion for angle and distance
                    if ((char_buffer[0] == 'A') && (char_buffer[3] == 'D'))
                    { // first byte should be an 'a' for ANGLE
                        if (char_buffer[1] == '+')
                        { // second byte is a '+', make angle integer
                            angle = buffer[2];
                        } else if (char_buffer[1] == '-')
                        { // second byte is a '-', make angle integer
                            angle = (buffer[2])*(-1);
                        } else
                        { // Error w/ UART data, did not find '+/-' in byte 2
                            ///LCD_ClearScreen();
                            ///LCD_PutString((char*)&ERROR,sizeof(ERROR)-1);
                            n_state = IDLE; // data error, go back to IDLE
                            __delay_ms(1000);
                        }
                        // grab the distance and decimal nums
                        distance = buffer[4];
                        distance_decimal = buffer[5];
                    } else
                    { // Error w/ UART data, did not find 'A' and 'D' in correct spots
                        ///LCD_ClearScreen();
                        ///LCD_PutString((char*)&ERROR,sizeof(ERROR)-1);
                        n_state = IDLE; // data error, go back to IDLE
                        __delay_ms(1000);
                    }
                } else
                {
                    ///LCD_ClearScreen();
                    ///LCD_PutString((char*)&no_kinect_message,sizeof(no_kinect_message)-1);
                    __delay_ms(100);
                    n_state = IDLE;
                }
                break;
                
            case CHECK_BEER :
                if (beer_PORT == 1) {
                    n_state = LOADING;
                } else {
                    n_state = CHECK_BEER; // do this for now, later go to IDLE
                    ///LCD_ClearScreen();
                    ///LCD_PutString((char*)&no_beer_string,sizeof(no_beer_string)-1);
                    __delay_ms(100);
                }
                break;
                // if beer -> LOADING
                // else -> IDLE && print NO BEER, DAB AGAIN W/ BEER
                
            case LOADING :
                ///LCD_ClearScreen();
                ///LCD_PutString((char*)&loading_string,sizeof(loading_string)-1);
                __delay_ms(1000);
                OC1_Start();
                servoRotate180();
                __delay_ms(5000);
                servoRotate0();
                __delay_ms(5000);
                OC1_Stop();
                n_state = LAUNCH_PREP;
                break;
                // move servo to release beer
                // move servo back to stop next beer
                // if launcher limit switch pressed -> LAUNCH_PREP
                // else -> LOADING
                
            case LAUNCH_PREP :
                ///LCD_ClearScreen();
                ///LCD_PutString((char*)&prep_string,sizeof(prep_string)-1);
                __delay_ms(100);
                n_state = LAUNCH_PREP;
                // turn on the air pump
                // start PWM loop
                // if at any point we get the pressure reading we need (turn off air pump) && were in the right position, BREAK
                // goto -> LAUNCHING
                break;
            
            case LAUNCH :
                // trigger solenoid pressure release
                // goto -> IDLE && transmit confirmation to laptop
                break;
                
            default : 
                state = IDLE;
                break;
        }
    }
    return (0);
}

void UART_testing()
{
    int i;
    ///char uart_string[] = "UART READY";
    //char uart_string1[] = "GOT 0x41";
    //char uart_string2[] = "READ 2";
    ///LCD_ClearScreen();
    ///LCD_PutString((char*)&uart_string,sizeof(uart_string)-1); // UART ready
    // number of characters to be read
    int buf_length = 5;
    // local variables to grab values in debugger
    unsigned int numBytesRead;
    // buffer to read to
    uint8_t buffer[buf_length];
    // initialize buffer to 0
    for (i=0; i < buf_length; i++) {buffer[i] = 0;}
    char data_buffer[buf_length];
    do
    {
        if(UART1_ReceiveBufferIsFull())
        {
            // buffer is full, read data buffer
            numBytesRead = UART1_ReadBuffer(buffer, buf_length);
            for (i=0; i < buf_length; i++) {data_buffer[i] = (char) (buffer[i]);}
            ///LCD_ClearScreen();
            ///LCD_PutString((char*)&data_buffer, buf_length);
        }
    } while (1);
    
    return;
}

void servoRotate0() //0 Degree
{
  OC1_0();
}

void servoRotate90() //90 Degree
{
  OC1_90();
}

void servoRotate180() //180 Degree
{
  OC1_180();
}

void pwm_testing ( void )
{
    ///char pwm_string[] = "Moving the Servo Motor...";
    ///LCD_ClearScreen();
    ///LCD_PutString((char*)&pwm_string,sizeof(pwm_string)-1);
    OC1_Start();
    /* Turn On LEDs*/
    ///LED_On ( LED_D10 ) ;
    //servoRotate90();
    do
    {
        servoRotate0();
        __delay_ms(2500);
        servoRotate90();
        __delay_ms(2500);
        servoRotate180();
        __delay_ms(2500);
    }while(1);
    return;
}

void limit_testing ( void )
{
    ///char limit_string1[] = "LIMIT SWITCH PRESSED";
    ///char limit_string2[] = "LIMIT SWITCH NOT PRESSED";
    ///char limit_string3[] = "READY FOR TESTING";
    ///LCD_ClearScreen();
    ///LCD_PutString((char*)&limit_string3,sizeof(limit_string3)-1);
    int flag = 0;
    OC1_Start();
    OC3_Start();
    do
    {
        if (beer_PORT == 1)
        {
            if (flag == 0)
            {
               ///LCD_ClearScreen();
               ///LCD_PutString((char*)&limit_string1,sizeof(limit_string1)-1);
               flag = 1;
               servoRotate180(); // move servo to 180 when limit switch is pressed
            }
        } else
        {
            if (flag == 1)
            {
               ///LCD_ClearScreen();
               ///LCD_PutString((char*)&limit_string2,sizeof(limit_string2)-1);
               flag = 0;
               servoRotate0(); // move servo back to 0 when limit switch is released
            }
        }
    }while(1);
    return;
}
